//! logistics 领域模型（DTO / Query / VO）。

pub mod logistics_company;
pub mod logistics_company_config;
pub mod print;
pub mod print_config;
pub mod print_log;
pub mod shipping_list;
pub mod shipping_tpl;
pub mod shipping_type;
pub mod sunmi_print_callback;
