//! identity 领域模型（DTO / Query / VO）。

pub mod admin_account;
pub mod admin_log;
pub mod admin_role;
pub mod admin_user;
pub mod auth;
pub mod authority;
